from telegram import Update
from telegram.ext import CallbackContext
from telegram.ext import Filters
from telegram.ext import MessageHandler
from telegram import KeyboardButton
from telegram import ReplyKeyboardMarkup
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram import ReplyKeyboardRemove
from telegram.ext import Updater
import requests
from bs4 import BeautifulSoup


def harorat(viloyat, update: Update, context: CallbackContext):
    link = f"https://obhavo.uz/{viloyat}"
    responce = requests.get(link).text
    soup = BeautifulSoup(responce, 'html.parser')
    natija = soup.find('strong').text
    update.message.reply_text(
        text=f"Hozir {viloyat} shaxrida harorat {natija}",
        reply_markup=None
    )

def message_handler(update: Update, context: CallbackContext):
    tugmalar = ReplyKeyboardMarkup(
        keyboard = [
                [
                KeyboardButton('Viloyatlar'),
                KeyboardButton('Biz bilan aloqa☎️'),
                ]
            ],
            resize_keyboard=True
            )

    viloyatlar = ReplyKeyboardMarkup(
        keyboard = [
            [
            KeyboardButton('Toshkent'),
            KeyboardButton('Jizzax'),
            ],
            [
            KeyboardButton('Andijon'),
            KeyboardButton('Buxoro'),
            ],
            [
            KeyboardButton('Guliston'),
            KeyboardButton('Zarafshon'),
            ],
            [
            KeyboardButton('Qarshi'),
            KeyboardButton('Navoiy'),
            ],
            [
            KeyboardButton('Namangan'),
            KeyboardButton('Termiz')
            ],
            [
            KeyboardButton('Urganch'),
            KeyboardButton('Farg`ona'),
            ],
            [
            KeyboardButton('Xiva'),
            KeyboardButton('Ortga qaytish 🔙')
            
            ]
        ],
        resize_keyboard=True
        )
    text = update.message.text
    ism = update.message.from_user.first_name
    if text == '/start':
        update.message.reply_text(
            text=f'Assalomu alaykum {ism}, botimizga xush kelipsiz! Pastdagi tugmalardan xoxlaganingizni tanlang!👇',
            reply_markup=tugmalar
            )
    elif text == '/help':
        update.message.reply_text(
            text='Sizga qanday yordam berishim mumkin!',
            reply_markup=None
            )
    elif text == 'Viloyatlar':
        update.message.reply_text(
            text='Viloyatni tanlang 👇',
            reply_markup=viloyatlar
            )
    elif text == 'Toshkent':
        harorat('tashkent', update=update, context=context)
    elif text == 'Andijon':
        harorat('andijan', update=update, context=context)
    elif text == 'Qarshi':
        harorat('karshi', update=update, context=context)
    elif text == 'Buxoro':
        harorat('bukhara', update=update, context=context)
    elif text == 'Jizzax':
        harorat('jizzakh', update=update, context=context)
    elif text == 'Zarafshon':
        harorat('zarafshan', update=update, context=context)
    elif text == 'Termiz':
        harorat('termez', update=update, context=context)
    elif text == 'Guliston':
        harorat('gulistan', update=update, context=context)
    elif text == 'Navoiy':
        harorat('navoi', update=update, context=context)
    elif text == 'Namangan':
        harorat('namangan', update=update, context=context)
    elif text == 'Nukus':
        harorat('nukus', update=update, context=context)
    elif text == 'Samarqand':
        harorat('samarkand', update=update, context=context)
    elif text == 'termiz':
        harorat('termez', update=update, context=context)
    elif text == 'Urganch':
        harorat('urgench', update=update, context=context)
    elif text == 'Farg`ona':
        harorat('ferghana', update=update, context=context)
    elif text == 'Xiva':
        harorat('khiva', update=update, context=context)

    elif text == 'Biz bilan aloqa☎️':
        update.message.reply_text(
            text=f'Telegram botda biron bir muammo yoki kamchilikni korsangiz https://t.me/abdullayev_abduaxad ga murojat qiling. Biz sizning savolingizga 24soat ichida javob  qaytaramiz!',
            reply_markup=None
            )
    elif text == 'Ortga qaytish 🔙':
        update.message.reply_text(
            text=f'Pastdagi tugmalardan xoxlaganingizni tanlang👇',
            reply_markup=tugmalar
            )
    else:
        update.message.reply_text(
            text='Siz bergan komanda menda yo`q',
            reply_markup=None)


def main():
    print('Dastur ishlayapdi')
    updater = Updater(
    token='6814938538:AAFBs6ICZxGHc5TqFAY86wZ_d6wFETLnL04',
    use_context=True,
    )
    updater.dispatcher.add_handler(MessageHandler(Filters.all, callback=message_handler))
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()